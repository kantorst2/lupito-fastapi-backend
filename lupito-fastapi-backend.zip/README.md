# Lupito FastAPI Backend

Backend API untuk ekstensi Chrome pengolah PDF.
